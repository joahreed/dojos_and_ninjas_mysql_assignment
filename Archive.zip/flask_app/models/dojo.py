from flask_app.config.mysqlconnection import connectToMySQL
from flask_app.models.ninja import Ninja

class Dojo:
    DB = 'dojos_ninjas_db'
    def __init__(self, data):
        self.id = data['id']
        self.name = data['name']
        self.created_at = data['created_at']
        self.updated_at = data['updated_at']
        self.ninjas = []

    @classmethod
    def get_all(cls):
        query = "Select * from dojos;"
        result = connectToMySQL(cls.DB).query_db(query)
        return result
        
    @classmethod
    def add(cls, data):
        query = "Insert into dojos (name) values (%(name)s)"
        result = connectToMySQL(cls.DB).query_db(query,data)
        return result
    
    #one to many classmethod
    @classmethod
    def get_dojo_with_ninjas(cls, data):
        #getting all the ninjas for the one dojo
        query = "Select * from dojos left join ninjas on  dojos.id = ninjas.dojo_id where dojos.id = %(dojo_id)s;"
        result = connectToMySQL(cls.DB).query_db(query,data)
        
        #printing result to see what we are getting back from db
        print('\n\n\nRESULT FROM GET DOJO WITH NINJAS ---->', result,'\n\n\n')
        
        #making an object of the one dojo
        dojo_object = cls(result[0])

        #for loop to make object of many ninjas
        for ninja in result:
            #getting ninja data ready to make an instance of ninja class
            ninja_data = {
                'id' : ninja['ninjas.id'],
                'first_name' : ninja['first_name'],
                'last_name' : ninja['last_name'],
                'age' : ninja['age'],
                'created_at' : ninja['ninjas.created_at'],
                'updated_at' : ninja['ninjas.updated_at'],
                'dojo_id' : ninja['dojo_id']
            }
            #making an instance of a ninja with the ninja data. this is being sent to the Ninja constructor!
            ninja_object = Ninja(ninja_data)
            #appending ninja object to array to hold the many ninjas related to the one dojo
            dojo_object.ninjas.append(ninja_object)   
        #one for loop is done we are returning the one dojo object which has the ninjas attribute which is an array that holds the many ninjas objects associated with it  
        return dojo_object