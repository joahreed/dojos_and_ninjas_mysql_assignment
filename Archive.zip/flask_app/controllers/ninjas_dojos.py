from flask_app import app
from flask import render_template, request, redirect, url_for
from flask_app.models.dojo import Dojo

@app.route("/")
def index():
    dojos = Dojo.get_all()
    return render_template("homepage.html", dojos = dojos)

@app.route('/dojos', methods=['POST'])
def dojos():
    Dojo.add(request.form)
    return redirect('/')

@app.route("/dojos/<int:dojo_id>")
def show_dojo(dojo_id):
    data = {"dojo_id" : dojo_id}
    dojo = Dojo.get_dojo_with_ninjas(data)
    print('\n\n\nDOJO OBJECT---->', dojo.ninjas[0].first_name,'\n\n\n')
        
    return render_template("show_dojo.html", dojo=dojo)

# @app.route("/ninjas/new")
# def ninja_new():
#     return render_template("new_ninja.html")

# @app.route("/ninjas", methods=["POST"])
# def ninja_create():
#     first_name = request.form["first_name"]
#     last_name = request.form["last_name"]
#     dojo_id = request.form["dojo_id"]
#     ninja = NinjasDojos.Ninja(first_name=first_name, last_name=last_name, dojo_id=dojo_id)
#     controller.save_ninja(ninja)
#     return redirect(url_for("dojo_show", dojo_id=dojo_id))
